<html>
	<head>
  <title>Student Information Form</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="CSS/Style.css">
</head>
	<body>

	<nav >
		<ul>
			<img src="images/logotwo.jpg" alt="logo imahe" height="50px" width="50px" />
        	<li><a href="index.php" title="Go to the Home page">Home</a></li>
        	<li><a href="theview.php" title="Go to the view page">View</a></li>
        </ul>
	</nav>

		<table>
			<tr>
				<th>Student Name</th>
				<th>Student Grade</th>
            </tr>
			<?php
			$conn  = mysqli_connect("localhost", "root", "", "nihal");
			$sql = "SELECT * FROM sinfo";
			$result = $conn->query($sql);

			if($result->num_rows > 0){
				while ($row = $result-> fetch_assoc()){
					echo "<tr><td>" . $row["sName"] . "</td><td>" . $row["sGrade"] . "</td></tr>";
				}
			}
			else{
				echo "NO Results/Entries..";
			}
			$conn->close();
			?>
		</table>
	</body>
	<footer>
  		<small>@ A WEBSITE BY MAyank Rangpariya </small>
	</footer>
</html>