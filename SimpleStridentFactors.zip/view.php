<html>
    <head>
        <title>Student Information Form</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="CSS/Style.css">
    </head>
    <body>
        <nav>
	    	<ul>
                <img src="images/logotwo.jpg" alt="logo imahe" height="50px" width="50px" />
                <li><a href="index.php" title="Go to the Home page">Home</a></li>
                <li><a href="theview.php" title="Go to the view page">View</a></li>
            </ul>
		</nav>
    </body>
    <footer>
        <small>@ A WEBSITE BY Mayank Rangpariya </small>
    </footer>
</html>    
    <?php
    if(isset($_POST['submit']))
    {
        $sName = $_POST['name'];
        $sGrade = $_POST['grade'];
    }

    $host = "localhost";
    $username = "root";
    $password = "";
    $dbname = "nihal";

    //creating connection
    $con = mysqli_connect($host, $username, $password, $dbname);

    if(!$con){
        die("Connection Failed" . mysqli_connect_error());
    }

    $sql = "INSERT INTO sinfo (sName, sGrade) VALUES ('$sName', '$sGrade')";

    $rs = mysqli_query($con, $sql);

    if($rs){
        echo "Entries Added Successfully....";
    }

    mysqli_close($con);
    ?>

  