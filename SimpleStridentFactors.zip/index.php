<!DOCTYPE html>
<html>
<head>
  <title>Student Information Form</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="CSS/Style.css">

</head>
<header>
      <nav>
				<ul>
        <img src="images/logotwo.jpg" alt="logo imahe" height="50px" width="50px" />
        <li><a href="index.php" title="Go to the Home page">Home</a></li>
        <li><a href="theview.php" title="Go to the view page">View</a></li>
        </ul>
			</nav>
</header>
<body>
      
  <h1>Student Information Form</h1>


  <?php
    echo "<h1><center>Enter New Student Grade</center></h1>";
  ?>

  <form action="view.php" method="post">
<center>
    <label for="name">Student Name:</label>
    <input type="text" id="name" name="name" required><br><br>

    <label for="grade">Student Grade:</label>
    <input type="text" id="grade" name="grade" required><br><br>

    <input type="submit" name="submit" value="Submit">
</center>
  </form>
  
</body>
<footer>
  <small>@ A WEBSITE BY Mayank</small>
</footer>
</html>
